<?php /* * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials * * @package
AR_Medical_Cosmetic */ ?>



<?php wp_footer(); ?>


</body>

</html>