<?php
get_header();
get_header( 'shop' ) ?>

<div class="mx-auto max-w-6xl">
    <?php
    // Get the current term
    $term = get_queried_object();
    ?>

    <div class="the-content">
        <?php echo term_description(); ?>

    </div>

    <?php
    // Query for products associated with the current ingredient term
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'tax_query' => array(
            array(
                'taxonomy' => $term->taxonomy,
                'field' => 'slug',
                'terms' => $term->slug,
            ),
        ),
    );
    $query = new WP_Query($args);

    if ($query->have_posts()): ?>
        <ul class="products-list">
            <?php while ($query->have_posts()):
                $query->the_post(); 
                wc_get_template_part('content', 'product');
            endwhile; ?>
        </ul>
    <?php else: ?>
        <p><?php echo __("No products for this ingredient","ar-medical");?></p>
    <?php endif; ?>

    <?php wp_reset_postdata(); ?>
</div>

<?php get_footer(); ?>