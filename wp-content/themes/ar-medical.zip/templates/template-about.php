<?php
/*
 * Template Name: Pagina About
 * Template Post Type: page
 */
get_header();

echo show_hero();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <section class="serviciu-list">
            <div class="container">
                <h1 class="entry-title">Despre noi</h1>
                
            </div>
        </section>
    </main>
</div>

<?php get_footer(); ?>